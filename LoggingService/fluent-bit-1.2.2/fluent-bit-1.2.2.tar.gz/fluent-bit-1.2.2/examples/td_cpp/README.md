# Fluent Bit / Treasure Data Output C++ Example

This example will build the example of a tool who writes data
to the [Treasure Data](http://treasuredata.com) service.

Once is built, the __td__ command will be available at _build/bin_,
note that the __td__ tool requires to load a configuration file, review
the _conf/_ directory for further details.
