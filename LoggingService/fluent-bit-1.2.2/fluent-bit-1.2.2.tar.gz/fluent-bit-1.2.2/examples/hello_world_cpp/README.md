# Fluent Bit / Hello World C++

This tool uses the Fluent Bit library version to flush data to one of the
registered outputs.

When using Fluent Bit as a library means the caller becomes the input.
