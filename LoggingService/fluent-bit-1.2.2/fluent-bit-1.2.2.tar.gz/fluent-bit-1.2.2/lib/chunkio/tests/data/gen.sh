tr -dc A-Za-z0-9 </dev/urandom | head -c 409600 > 400kb.txt
