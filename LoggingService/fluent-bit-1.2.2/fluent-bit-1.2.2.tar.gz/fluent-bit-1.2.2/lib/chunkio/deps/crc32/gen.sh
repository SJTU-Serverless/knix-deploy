./pycrc.py --generate c --algorithm table-driven --model crc-32 --slice-by 8 -o crc32.c
./pycrc.py --generate h --algorithm table-driven --model crc-32 --slice-by 8 -o crc32.h
