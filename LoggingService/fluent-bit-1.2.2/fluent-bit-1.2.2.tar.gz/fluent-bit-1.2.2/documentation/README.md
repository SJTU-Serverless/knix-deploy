# Fluent Bit Documentation

For every [Fluent Bit](http://fluentbit.io) release there is full documentation, the most updated documents can be found in the following link:

[http://fluentbit.io/documentation](http://fluentbit.io/documentation)

### Documentation Sources

If you are interested into provide some documentation contribution, please refer to the following GIT repository for more details:

[http://github.com/fluent/fluent-bit-docs](http://github.com/fluent/fluent-bit-docs)
